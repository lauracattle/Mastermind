﻿using System;
using MeasureFormula.Common_Code;
using NUnit.Framework;
namespace MeasureFormula.Tests.CommonCodeTests
{
    [TestFixture]
    public class CarbonHelperTests
    {
        private double _lossOfGasCubicMeter;
        private double _carbonLossOfGas;
        private int    _baseYear;
        private double _changeYear;
        private double _carbonCoefficientA;
        private double _carbonCoefficientB;
        private double _carbonCoefficientC;
        private int    _startFiscalYear;
        private int    _months;
            
        [SetUp]
        public void GetFixtureSetup()
        {
            _lossOfGasCubicMeter = 1;
            _carbonLossOfGas=2;
            _baseYear=2015;
            _changeYear=2019;
            _carbonCoefficientA=5;
            _carbonCoefficientB=6;
            _carbonCoefficientC=7;
            _startFiscalYear=2016;
            _months=180;
        }

        [Test]
        public void CalculateCarbonValues_WhenInputDataIsOk_ReturnsCorrectResult()
        {
            _baseYear=2017;
            var expectedResultWhenBaseYearGtStartYear = new double?[]
            {
                null, null, null, null, null, null, null, null, null, null, null, null, 4024d, 4024d, 4024d, 4024d,
                4024d, 4024d, 4024d, 4024d, 4024d, 4024d, 4024d, 4024d, 4026d, 4026d, 4026d, 4026d, 4026d, 4026d, 4026d,
                4026d, 4026d, 4026d, 4026d, 4026d, 4028d, 4028d, 4028d, 4028d, 4028d, 4028d, 4028d, 4028d, 4028d, 4028d,
                4028d, 4028d, 24226d, 24226d, 24226d, 24226d, 24226d, 24226d, 24226d, 24226d, 24226d, 24226d, 24226d,
                24226d, 24238d, 24238d, 24238d, 24238d, 24238d, 24238d, 24238d, 24238d, 24238d, 24238d, 24238d, 24238d,
                24250d, 24250d, 24250d, 24250d, 24250d, 24250d, 24250d, 24250d, 24250d, 24250d, 24250d, 24250d, 24262d,
                24262d, 24262d, 24262d, 24262d, 24262d, 24262d, 24262d, 24262d, 24262d, 24262d, 24262d, 24274d, 24274d,
                24274d, 24274d, 24274d, 24274d, 24274d, 24274d, 24274d, 24274d, 24274d, 24274d, 24286d, 24286d, 24286d,
                24286d, 24286d, 24286d, 24286d, 24286d, 24286d, 24286d, 24286d, 24286d, 24298d, 24298d, 24298d, 24298d,
                24298d, 24298d, 24298d, 24298d, 24298d, 24298d, 24298d, 24298d, 24310d, 24310d, 24310d, 24310d, 24310d,
                24310d, 24310d, 24310d, 24310d, 24310d, 24310d, 24310d, 24322d, 24322d, 24322d, 24322d, 24322d, 24322d,
                24322d, 24322d, 24322d, 24322d, 24322d, 24322d, 24334d, 24334d, 24334d, 24334d, 24334d, 24334d, 24334d,
                24334d, 24334d, 24334d, 24334d, 24334d, 24346d, 24346d, 24346d, 24346d, 24346d, 24346d, 24346d, 24346d,
                24346d, 24346d, 24346d, 24346d
            };

            var resultWhenBaseYearGtStartYear = CarbonHelper.CalculateCarbonValues(_lossOfGasCubicMeter,
                _carbonLossOfGas,
                _baseYear,
                _changeYear,
                _carbonCoefficientA,
                _carbonCoefficientB,
                _carbonCoefficientC,
                _startFiscalYear,
                _months);
            for(int i=0;i<_months;i++)
                Console.Write(resultWhenBaseYearGtStartYear[i]+ "d ,");

            Assert.That(resultWhenBaseYearGtStartYear, Is.EqualTo(expectedResultWhenBaseYearGtStartYear));
            
            _baseYear=2015;
            var expectedResultWhenBaseYearLtStartYear = new double?[]
            {
                4022d, 4022d, 4022d, 4022d, 4022d, 4022d, 4022d, 4022d, 4022d, 4022d, 4022d, 4022d, 4024d, 4024d, 4024d,
                4024d, 4024d, 4024d, 4024d, 4024d, 4024d, 4024d, 4024d, 4024d, 4026d, 4026d, 4026d, 4026d, 4026d, 4026d,
                4026d, 4026d, 4026d, 4026d, 4026d, 4026d, 4028d, 4028d, 4028d, 4028d, 4028d, 4028d, 4028d, 4028d, 4028d,
                4028d, 4028d, 4028d, 24226d, 24226d, 24226d, 24226d, 24226d, 24226d, 24226d, 24226d, 24226d, 24226d,
                24226d, 24226d, 24238d, 24238d, 24238d, 24238d, 24238d, 24238d, 24238d, 24238d, 24238d, 24238d, 24238d,
                24238d, 24250d, 24250d, 24250d, 24250d, 24250d, 24250d, 24250d, 24250d, 24250d, 24250d, 24250d, 24250d,
                24262d, 24262d, 24262d, 24262d, 24262d, 24262d, 24262d, 24262d, 24262d, 24262d, 24262d, 24262d, 24274d,
                24274d, 24274d, 24274d, 24274d, 24274d, 24274d, 24274d, 24274d, 24274d, 24274d, 24274d, 24286d, 24286d,
                24286d, 24286d, 24286d, 24286d, 24286d, 24286d, 24286d, 24286d, 24286d, 24286d, 24298d, 24298d, 24298d,
                24298d, 24298d, 24298d, 24298d, 24298d, 24298d, 24298d, 24298d, 24298d, 24310d, 24310d, 24310d, 24310d,
                24310d, 24310d, 24310d, 24310d, 24310d, 24310d, 24310d, 24310d, 24322d, 24322d, 24322d, 24322d, 24322d,
                24322d, 24322d, 24322d, 24322d, 24322d, 24322d, 24322d, 24334d, 24334d, 24334d, 24334d, 24334d, 24334d,
                24334d, 24334d, 24334d, 24334d, 24334d, 24334d, 24346d, 24346d, 24346d, 24346d, 24346d, 24346d, 24346d,
                24346d, 24346d, 24346d, 24346d, 24346d
            };
            
            var resultWhenBaseYearLtStartYear = CarbonHelper.CalculateCarbonValues(_lossOfGasCubicMeter,
                _carbonLossOfGas,
                _baseYear,
                _changeYear,
                _carbonCoefficientA,
                _carbonCoefficientB,
                _carbonCoefficientC,
                _startFiscalYear,
                _months);

            Assert.That(expectedResultWhenBaseYearLtStartYear, Is.EqualTo(resultWhenBaseYearLtStartYear));
        }
    }
    
    
}
