﻿using System;
using MeasureFormula.Common_Code;
using NUnit.Framework;

namespace MeasureFormula.Tests.CommonCodeTests
{
    [TestFixture]
    public class DeteriorationHelperTests
    {
        private int _year;
        private int _controlSystem;
        private double _start;
        private double _csDeterioration;
        private int _startFiscalYear;
        private int _months;
        
        [SetUp]
        public void FixtureSetup()
        {
            _year = 2019;
            _controlSystem = 2;
            _start = 0.1;
            _csDeterioration = 0.05d;
            _startFiscalYear = 2018;
            _months = 60;
        }

        [Test]
        public void DeteriorateAndFill_WhenInputDataIsCorrect_ReturnsCorrectResult()
        {
            //deterioration formula = ( CONTROL_SYSTEM * exp( DYear * cs_deterioration))
            var expectedValuePerYear = new double?[]
            {
                null,
                _controlSystem * Math.Exp(0 * _csDeterioration) / 12,
                _controlSystem * Math.Exp(1 * _csDeterioration) / 12,
                _controlSystem * Math.Exp(2 * _csDeterioration) / 12,
                _controlSystem * Math.Exp(3 * _csDeterioration) / 12,
                _controlSystem * Math.Exp(4 * _csDeterioration) / 12
            };
            
            var result = DeteriorationHelper.DeteriorateAndFill(_controlSystem, _csDeterioration, _startFiscalYear, _months, 'D', null, _year);
            for( var i = 0; i< result.Length; i++)
            {
                Assert.That(result[i], Is.EqualTo(expectedValuePerYear[i/12]).Within(CommonConstants.DoubleDifferenceTolerance));
            }
        }
        
        [Test]
        public void DeteriorateAndFill_WhenInputDataComputesInfOrNaN_ReturnsNull()
        {
            //With these parameters the function will compute an infinity value
            _year = 100;
            _csDeterioration = 0.9d;
            
            var result = DeteriorationHelper.DeteriorateAndFill(_controlSystem, _csDeterioration, _startFiscalYear, _months, 'D', null, _year);
            
            for( var i = 0; i< result.Length; i++)
            {
                Assert.That(result[i], Is.Null);
            }
 
            //With these parameters the function will compute an NaN value
            _year = 100;
            _controlSystem = 0;
            
            result = DeteriorationHelper.DeteriorateAndFill(_controlSystem, _csDeterioration, _startFiscalYear, _months, 'D', null, _year);
            for( var i = 0; i< result.Length; i++)
            {
                Assert.That(result[i], Is.Null);
            }           
        }
    }
}