﻿using System;
using System.Linq;
using MeasureFormula.Common_Code;
using NUnit.Framework;

namespace MeasureFormula.Tests.CommonCodeTests
{
    [TestFixture]
    public class HealthAndRiskIndexHelperTests
    {
        private const int Months = 180;
        private const int StartFiscalYear = 2015;
        private double?[] _array1;
        
        [SetUp]
        public void FixtureSetup()
        {
            _array1 = Enumerable.Range(0, Months).Select( x => (double?)x + 1d).ToArray();
            _array1[10] = null;
        }

        [Test]
        public void GetBandForSingleAsset_WhenInputDataIsCorrect_ReturnsCorrectResult()
        {
            var expectedResultArray = Enumerable.Range(0, Months).Select( x =>  (int?)10).ToArray();

            var bandCounter = 0;
            var bandValue = 1;
            for (var month = 0; month < 90; month++)
            {
                bandCounter++;
                if (bandCounter > 10)
                {
                    bandValue++;
                    bandCounter = 1;
                }
                expectedResultArray[month] = bandValue;
            }

            expectedResultArray[10] = null;
            
            var result = HealthAndRiskIndexHelper.GetBandForSingleAsset(_array1,
                                                                        10 * 12,
                                                                        20 * 12,
                                                                        30 * 12,
                                                                        40 * 12,
                                                                        50 * 12,
                                                                        60 * 12,
                                                                        70 * 12,
                                                                        80 * 12,
                                                                        90 * 12,
                                                                        Months);
            Assert.That(result, Is.EqualTo(expectedResultArray));

            for (var month = 11; month < 20; month++)
                expectedResultArray[month] = 3;
            
            result = HealthAndRiskIndexHelper.GetBandForSingleAsset(_array1,
                                                                        10 * 12,
                                                                        null,
                                                                        30 * 12,
                                                                        40 * 12,
                                                                        50 * 12,
                                                                        60 * 12,
                                                                        70 * 12,
                                                                        80 * 12,
                                                                        90 * 12,
                                                                        Months);
            Assert.That(result, Is.EqualTo(expectedResultArray));
        }

        [Test]
        public void GetBandForSingleAsset_WhenInputRawDataIsNull_ReturnsNullArray()
        {
            Assert.That(
                HealthAndRiskIndexHelper.GetBandForSingleAsset(null,
                                                               10 * 12,
                                                               null,
                                                               30 * 12,
                                                               40 * 12,
                                                               50 * 12,
                                                               60 * 12,
                                                               70 * 12,
                                                               80 * 12,
                                                               90 * 12,
                                                               Months),
                Is.EqualTo(new double?[Months]));
        }
    }
}

