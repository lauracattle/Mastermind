﻿using System;
using System.Linq;
using MeasureFormula.Common_Code;
using NUnit.Framework;

namespace MeasureFormula.Tests.CommonCodeTests
{
    [TestFixture]
    public class ArrayHelperTests : ExceptionCheckerPreparationBase
    {
        private const int Months = 180;
        private const int StartFiscalYear = 2015;
        private double?[] _array1;
        private double?[] _array2;
        private double?[] _array3;
        private double?[] _array4;
        
        [SetUp]
        public void FixtureSetup()
        {
            _array1 = Enumerable.Range(0, Months).Select( x => (double?)x + 1d).ToArray();
            _array2 = Enumerable.Range(0, Months).Select( x => (double?)x + 1d).ToArray();
            _array3 = Enumerable.Range(0, Months).Select( x => (double?)x + 1d).ToArray();
            _array4 = Enumerable.Range(0, Months).Select( x => (double?)x + 1d).ToArray();
        }

        [Test]
        public void SumArraysAfterDate_WhenInputDataIsCorrect_ReturnsCorrectResult()
        {
            var expectedResultArray = Enumerable.Range(0, Months).Select( x => 4 *( (double?)x + 1d)).ToArray();

            var date = new DateTime(2016, 5, 1);
            //var date = new DateTime(2015, 1, 1);
            var monthStart = (date.Year - StartFiscalYear + 1) * 12 + date.Month - 4;
            for(var month=0;month<monthStart;month++)
            {
                expectedResultArray[month] = null;
            }
            
            var result = ArrayHelper.SumArraysAfterDate(Months, date, StartFiscalYear, _array1,_array2,_array3,_array4);
            Assert.That(result, Is.EqualTo(expectedResultArray));
        }
    }
}

