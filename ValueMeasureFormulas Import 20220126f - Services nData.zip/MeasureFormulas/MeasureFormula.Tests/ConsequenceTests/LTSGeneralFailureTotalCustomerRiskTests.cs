using MeasureFormula.TestHelpers;
using System;
using System.Collections.Generic;
using AutoFixture;
using NUnit.Framework;
using FormulaClass = CustomerFormulaCode.LTSGeneralFailureTotalCustomerRisk;
using TimeInvariantInputDTO = MeasureFormulas.Generated_Formula_Base_Classes.LTSGeneralFailureTotalCustomerRiskBase.TimeInvariantInputDTO;
using TimeVariantInputDTO = MeasureFormulas.Generated_Formula_Base_Classes.LTSGeneralFailureTotalCustomerRiskBase.TimeVariantInputDTO;

namespace MeasureFormula.Tests.ConsequenceTests
{
    [TestFixture]
    public class LTSGeneralFailureTotalCustomerRiskTests : ExceptionCheckerPreparationBase
    {
        private readonly FormulaClass _formulas = new FormulaClass();
        private TimeInvariantInputDTO _timeInvariantInput;
        private IReadOnlyList<TimeVariantInputDTO> _timeVariantInput;

        [SetUp]
        public void FixtureSetup()
        {
            SetConstructorParameters(typeof(TimeInvariantInputDTO).GetConstructors()[0]);
            _timeInvariantInput = fixture.Create<TimeInvariantInputDTO>();
            _timeVariantInput = fixture.Create<IReadOnlyList<TimeVariantInputDTO>>();
        }

        [Test]
        public void ExceptionChecks()
        {
            Func<int, int, object, object, double?[]> getUnitsCall =
                (startYear, months, timeInvariantData, timeVariantData) => _formulas.GetUnits(startYear,
                    months,
                    (TimeInvariantInputDTO) timeInvariantData,
                    (IReadOnlyList<TimeVariantInputDTO>) timeVariantData);

            Assert.DoesNotThrow(() =>
            {
                ExceptionChecker.CheckForExceptions(
                    ArbitraryStartYear,
                    ArbitraryMonths,
                    _timeInvariantInput,
                    _timeVariantInput,
                    getUnitsCall);
            });
        }
    }
}

