using MeasureFormula.TestHelpers;
using System;
using System.Collections.Generic;
using AutoFixture;
using CL.FormulaHelper.DTOs;
using MeasureFormulas.Generated_Formula_Base_Classes;
using NUnit.Framework;
using FormulaClass = CustomerFormulaCode.nESCarbonRisk;
using TimeInvariantInputDTO = MeasureFormulas.Generated_Formula_Base_Classes.nESCarbonRiskBase.TimeInvariantInputDTO;
using TimeVariantInputDTO = MeasureFormulas.Generated_Formula_Base_Classes.nESCarbonRiskBase.TimeVariantInputDTO;

namespace MeasureFormula.Tests.ConsequenceTests
{
    [TestFixture]
    public class nESCarbonRiskTests : ExceptionCheckerPreparationBase
    {
        private readonly FormulaClass _formulas = new FormulaClass();
        private TimeInvariantInputDTO _timeInvariantInput;
        private IReadOnlyList<TimeVariantInputDTO> _timeVariantInput;

        [SetUp]
        public void FixtureSetup()
        {
            SetConstructorParameters(typeof(TimeInvariantInputDTO).GetConstructors()[0]);
            
            var timeSeriesDto = new TimeSeriesDTO();
            //SetConstructorParameterByName(nameof(ESCarbonRiskBase.TimeInvariantInputDTO.SystemNon_45_traded_32_price_32_of_32_carbon_32__40_per_32_Tonnes_32_C02e_41_), timeSeriesDto);
            
            _timeInvariantInput = fixture.Create<TimeInvariantInputDTO>();
            _timeVariantInput = fixture.Create<IReadOnlyList<TimeVariantInputDTO>>();
        }

        [Test]
        public void ExceptionChecks()
        {
            Func<int, int, object, object, double?[]> getUnitsCall =
                (startYear, months, timeInvariantData, timeVariantData) => _formulas.GetUnits(startYear,
                    months,
                    (TimeInvariantInputDTO) timeInvariantData,
                    (IReadOnlyList<TimeVariantInputDTO>) timeVariantData);

            Assert.DoesNotThrow(() =>
            {
                ExceptionChecker.CheckForExceptions(
                    ArbitraryStartYear,
                    ArbitraryMonths,
                    _timeInvariantInput,
                    _timeVariantInput,
                    getUnitsCall);
            });
        }
    }
}

