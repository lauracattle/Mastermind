using System;
using System.Collections.Generic;
using AutoFixture;
using MeasureFormula.TestHelpers;
using NUnit.Framework;
using ArrayHelper = MeasureFormula.Common_Code.ArrayHelper;
using FormulaClass = CustomerFormulaCode.MainsRiskandHealthTotalsExpectedFailures;
using TimeInvariantInputDTO = MeasureFormulas.Generated_Formula_Base_Classes.MainsRiskandHealthTotalsExpectedFailuresBase.TimeInvariantInputDTO;
using TimeVariantInputDTO = MeasureFormulas.Generated_Formula_Base_Classes.MainsRiskandHealthTotalsExpectedFailuresBase.TimeVariantInputDTO;
namespace MeasureFormula.Tests.ConsequenceTests
{
    
    [TestFixture]
    public class MainsRiskandHealthTotalsExpectedFailuresTests : MainsRiskAndHealthTotalsTestBase
    {
        private readonly FormulaClass _formulas = new FormulaClass();
        private TimeInvariantInputDTO _timeInvariantInput;
        private TimeVariantInputDTO[] _timeVariantInput;
        
        [SetUp]
        public void FixtureSetup()
        {
            SetConstructorParameterByName("AssetTotal_32_Mains_32_Length", _assetTotalMainsLength);
            SetConstructorParameterByName(
                "Mains_32__45__32_Corrosion_Mains_32__45__32_Corrosion_32__45__32_Number_32_of_32_Failures_LikelihoodUnitOutput", _corrosionFactor);
            SetConstructorParameterByName(
                "Mains_32__45__32_Joint_Mains_32__45__32_Joint_32__45__32_Number_32_of_32_Failures_LikelihoodUnitOutput", _jointFactor);
            SetConstructorParameterByName(
                "Mains_32__45__32_Fracture_Mains_32__45__32_Fracture_32__45__32_Number_32_of_32_Failures_LikelihoodUnitOutput", _fractureFactor);
            
            
            _timeInvariantInput = fixture.Create<TimeInvariantInputDTO>();
            _timeVariantInput =
                DataPrep.BuildTimeVariantData<TimeVariantInputDTO>(fixture, ArbitraryStartYear);
        }
        
        [Test]
        public void ExceptionTest()
        {
            Func<int, int, object, object, double?[]> getUnitsCall =
                (startYear, months, timeInvariantData, timeVariantData) => _formulas.GetUnits(ArbitraryStartYear,
                    ArbitraryMonths,
                    (TimeInvariantInputDTO) timeInvariantData,
                    (IReadOnlyList<TimeVariantInputDTO>) timeVariantData);
            Assert.DoesNotThrow(() =>
            {
                ExceptionChecker.CheckForExceptions(ArbitraryStartYear,
                    ArbitraryMonths,
                    _timeInvariantInput,
                    _timeVariantInput,
                    getUnitsCall);
            });
        }
        
        [Test]
        public void GetUnits_WhenFailureMultiplierIsNull_ReturnsTotalFailures()
        {
            DataPrep.SetPropertyToNull(_timeInvariantInput, "AssetTotal_32_Mains_32_Length");
            
            var output = _formulas.GetUnits(ArbitraryStartYear,
                ArbitraryMonths,
                _timeInvariantInput,
                _timeVariantInput);

            var totalFailures = Common_Code.ArrayHelper.SumArrays(ArbitraryMonths,
                _corrosionFactor, _fractureFactor, _jointFactor);

            var expectedOutput =
                ArrayHelper.MultiplyStreamOfValuesByConstant(totalFailures, 1000/1000);
                
            Assert.That(output, Is.EqualTo(expectedOutput));
        }
        
        [Test]
        public void GetUnits_WhenAllFailuresAreNull_ReturnsNull()
        {
            DataPrep.SetPropertyToNull(_timeInvariantInput,
                "Mains_32__45__32_Fracture_Mains_32__45__32_Fracture_32__45__32_Number_32_of_32_Failures_LikelihoodUnitOutput");
            DataPrep.SetPropertyToNull(_timeInvariantInput,
                "Mains_32__45__32_Corrosion_Mains_32__45__32_Corrosion_32__45__32_Number_32_of_32_Failures_LikelihoodUnitOutput");
            DataPrep.SetPropertyToNull(_timeInvariantInput,
                "Mains_32__45__32_Joint_Mains_32__45__32_Joint_32__45__32_Number_32_of_32_Failures_LikelihoodUnitOutput");
	        
            var output = _formulas.GetUnits(ArbitraryStartYear,
                ArbitraryMonths,
                _timeInvariantInput,
                _timeVariantInput);

            Assert.That(output, Is.Null);
        }
        
        [Test]
        public void GetUnits_WhenFractureFailuresAreNull_ComputesCorrectly()
        {
            DataPrep.SetPropertyToNull(_timeInvariantInput,
                "Mains_32__45__32_Fracture_Mains_32__45__32_Fracture_32__45__32_Number_32_of_32_Failures_LikelihoodUnitOutput");
	        
            var output = _formulas.GetUnits(ArbitraryStartYear,
                ArbitraryMonths,
                _timeInvariantInput,
                _timeVariantInput);
            
            var totalFailures = Common_Code.ArrayHelper.SumArrays(ArbitraryMonths,
                _corrosionFactor, null, _jointFactor);

            var expectedOutput =
                ArrayHelper.MultiplyStreamOfValuesByConstant(totalFailures, 1000 / _assetTotalMainsLength);

            Assert.That(output, Is.EqualTo(expectedOutput));
        }
        
        [Test]
        public void GetUnits_WhenJointFailuresAreNull_ComputesCorrectly()
        {
            DataPrep.SetPropertyToNull(_timeInvariantInput, "Mains_32__45__32_Joint_Mains_32__45__32_Joint_32__45__32_Number_32_of_32_Failures_LikelihoodUnitOutput");
	        
            var output = _formulas.GetUnits(ArbitraryStartYear,
                ArbitraryMonths,
                _timeInvariantInput,
                _timeVariantInput);
            
            var totalFailures = Common_Code.ArrayHelper.SumArrays(ArbitraryMonths,
                _corrosionFactor, _fractureFactor, null);

            var expectedOutput =
                ArrayHelper.MultiplyStreamOfValuesByConstant(totalFailures, 1000 / _assetTotalMainsLength);

            Assert.That(output, Is.EqualTo(expectedOutput));
        }
        
        [Test]
        public void GetUnits_WhenCorrosionFailuresAreNull_ComputesCorrectly()
        {
            DataPrep.SetPropertyToNull(_timeInvariantInput,
                "Mains_32__45__32_Corrosion_Mains_32__45__32_Corrosion_32__45__32_Number_32_of_32_Failures_LikelihoodUnitOutput");
	        
            var output = _formulas.GetUnits(ArbitraryStartYear,
                ArbitraryMonths,
                _timeInvariantInput,
                _timeVariantInput);
            
            var totalFailures = Common_Code.ArrayHelper.SumArrays(ArbitraryMonths,
                null, _fractureFactor, _jointFactor);

            var expectedOutput =
                ArrayHelper.MultiplyStreamOfValuesByConstant(totalFailures, 1000 / _assetTotalMainsLength);

            Assert.That(output, Is.EqualTo(expectedOutput));
        }

        [Test]
        public void GetUnits_WhenPassedValidInputs_ComputesCorrectly()
        {
            var output = _formulas.GetUnits(ArbitraryStartYear,
                ArbitraryMonths,
                _timeInvariantInput,
                _timeVariantInput);

            var totalFailures = Common_Code.ArrayHelper.SumArrays(ArbitraryMonths,
                _corrosionFactor, _fractureFactor, _jointFactor);

            var expectedOutput =
                ArrayHelper.MultiplyStreamOfValuesByConstant(totalFailures, 1000 / _assetTotalMainsLength);
                
            Assert.That(output, Is.EqualTo(expectedOutput));
        }
        
        [Test]
        public void GetZynos_WhenInputsAreValid_ConvertsToZynos()
        {
            Assert.DoesNotThrow(() =>
            {
                ZynosTest.RunGetZynosTest(fixture,
                    ArbitraryStartYear,
                    ArbitraryMonths,
                    _timeInvariantInput,
                    _timeVariantInput,
                    typeof(FormulaClass),
                    DataPrep.ZynosTestType.NoValidZynosConversion,
                    null);
            });
        }
    }
}